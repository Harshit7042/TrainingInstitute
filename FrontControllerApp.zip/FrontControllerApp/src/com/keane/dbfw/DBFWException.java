package com.keane.dbfw;

public class DBFWException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DBFWException(String arg0) {
		super(arg0);

	}

	public DBFWException(Throwable arg0) {
		super(arg0);

	}

	public DBFWException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

}
